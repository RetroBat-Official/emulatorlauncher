#ifndef __GETOPT_H___
#define __GETOPT_H___
int getopt(int argc, char * const argv[], const char *optstring);
void __getopt_msg(const char *a, const char *b, const char *c, size_t l);
#endif