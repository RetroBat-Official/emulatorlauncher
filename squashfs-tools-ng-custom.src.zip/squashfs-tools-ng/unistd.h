#include <io.h>
#include <stdint.h>
#include <stdio.h>
#include <sys/types.h>
#include <BaseTsd.h>

#define ssize_t SSIZE_T
typedef long int __off_t;

#define STDIN_FILENO 0
#define STDOUT_FILENO 0